<%@ page contentType="text/html;charset=UTF-8" language="java" isErrorPage="true" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Erreur – Gestion des Produits</title>
    <link rel="stylesheet" href="${pageContext.request.contextPath}/css/style.css">
</head>
<body>
<%
    Integer code = (Integer) request.getAttribute("erreurCode");
    if (code == null) {
        Object sc = request.getAttribute("javax.servlet.error.status_code");
        code = (sc != null) ? (Integer) sc : 500;
    }
    request.setAttribute("codeAffiche", code);

    String msg = (String) request.getAttribute("erreurMessage");
    if (msg == null) {
        Object em = request.getAttribute("javax.servlet.error.message");
        if (em != null && !em.toString().isEmpty()) {
            msg = em.toString();
        } else if (code == 404) {
            msg = "La page demandée est introuvable ou a été déplacée.";
        } else if (code == 403) {
            msg = "Vous n'avez pas les droits nécessaires pour accéder à cette ressource.";
        } else {
            msg = "Une erreur inattendue s'est produite. Veuillez réessayer.";
        }
    }
    request.setAttribute("msgAffiche", msg);
%>
<div class="erreur-page">
    <div class="erreur-code-grand">${codeAffiche}</div>
    <h1 class="erreur-titre">
        <c:choose>
            <c:when test="${codeAffiche == 403}">Accès refusé</c:when>
            <c:when test="${codeAffiche == 404}">Page introuvable</c:when>
            <c:otherwise>Erreur serveur</c:otherwise>
        </c:choose>
    </h1>
    <p class="erreur-msg">${msgAffiche}</p>
    <div class="erreur-actions">
        <a href="${pageContext.request.contextPath}/listProduits" class="btn btn-primaire">Retour à l'accueil</a>
        <a href="javascript:history.back()" class="btn btn-annuler">Page précédente</a>
    </div>
</div>
</body>
</html>
