<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Connexion – Gestion des Produits</title>
    <link rel="stylesheet" href="${pageContext.request.contextPath}/css/style.css">
</head>
<body>
<div class="login-fond">
    <div class="login-boite">

        <div class="login-entete">
            <h1>Gestion des Produits</h1>
            <div class="separateur"></div>
        </div>

        <div class="login-cadre">

            <c:if test="${not empty erreur}">
                <div class="alerte alerte-erreur">${erreur}</div>
            </c:if>

            <form action="${pageContext.request.contextPath}/login" method="post">

                <div class="form-champ">
                    <label for="login">Identifiant</label>
                    <input type="text"
                           id="login"
                           name="login"
                           placeholder="votre login"
                           value="${loginSaisi}"
                           required
                           autofocus />
                </div>

                <div class="form-champ">
                    <label for="motDePasse">Mot de passe</label>
                    <input type="password"
                           id="motDePasse"
                           name="motDePasse"
                           placeholder="votre mot de passe"
                           required />
                </div>

                <button type="submit" class="btn-connexion">Se connecter</button>
            </form>
        </div>

        <div class="login-aide">
            <strong>Comptes de test</strong>
            Admin &nbsp;&rarr;&nbsp; <code>admin</code> / <code>admin123</code><br>
            Utilisateur &rarr; <code>user</code> / <code>user123</code>
        </div>

    </div>
</div>
</body>
</html>
