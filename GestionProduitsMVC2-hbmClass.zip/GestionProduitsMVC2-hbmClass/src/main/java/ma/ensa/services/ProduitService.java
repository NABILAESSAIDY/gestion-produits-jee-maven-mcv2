package ma.ensa.services;

import ma.ensa.models.Produit;
import java.util.List;

public interface ProduitService {
    void add(Produit p);
    void delete(Long id);
    void update(Produit p);
    Produit getById(Long id);
    List<Produit> getAll();
}