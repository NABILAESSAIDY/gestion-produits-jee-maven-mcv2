package ma.ensa.services;

import ma.ensa.models.Utilisateur;
import ma.ensa.models.Utilisateur.Role;
import java.util.HashMap;
import java.util.Map;

public class AuthService {

    private static AuthService instance;
    private final Map<String, Utilisateur> users = new HashMap<>();

    private AuthService() {
        users.put("admin", new Utilisateur("admin", "admin123", Role.ADMIN));
        users.put("user",  new Utilisateur("user",  "user123",  Role.USER));
    }

    public static AuthService getInstance() {
        if (instance == null) instance = new AuthService();
        return instance;
    }

    public Utilisateur authentifier(String login, String mdp) {
        Utilisateur u = users.get(login);
        return (u != null && u.getMotDePasse().equals(mdp)) ? u : null;
    }
}