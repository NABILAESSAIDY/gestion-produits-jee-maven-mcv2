package ma.ensa.services;

import ma.ensa.dao.ProduitDAO;
import ma.ensa.dao.ProduitDAOImpl;
import ma.ensa.models.Produit;
import java.util.List;

public class ProduitServiceImpl implements ProduitService {

    private static ProduitServiceImpl instance;
    private final ProduitDAO dao = new ProduitDAOImpl();

    private ProduitServiceImpl() {}

    public static synchronized ProduitServiceImpl getInstance() {
        if (instance == null) instance = new ProduitServiceImpl();
        return instance;
    }

    @Override public void add(Produit p)      { dao.add(p); }
    @Override public void delete(Long id)     { dao.delete(id); }
    @Override public void update(Produit p)   { dao.update(p); }
    @Override public Produit getById(Long id) { return dao.getById(id); }
    @Override public List<Produit> getAll()   { return dao.getAll(); }
}