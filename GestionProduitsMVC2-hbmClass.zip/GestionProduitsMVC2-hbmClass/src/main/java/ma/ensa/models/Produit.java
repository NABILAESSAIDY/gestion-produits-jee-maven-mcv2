package ma.ensa.models;

public class Produit {

    private Long idProduit;
    private String nom;
    private String description;
    private Double prix;

    public Produit() {}

    public Produit(String nom, String description, Double prix) {
        this.nom = nom;
        this.description = description;
        this.prix = prix;
    }

    public Long getIdProduit()           { return idProduit; }
    public void setIdProduit(Long id)    { this.idProduit = id; }
    public String getNom()               { return nom; }
    public void setNom(String nom)       { this.nom = nom; }
    public String getDescription()       { return description; }
    public void setDescription(String d) { this.description = d; }
    public Double getPrix()              { return prix; }
    public void setPrix(Double prix)     { this.prix = prix; }
}