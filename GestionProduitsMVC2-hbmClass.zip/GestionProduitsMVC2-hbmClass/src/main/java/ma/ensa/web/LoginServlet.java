package ma.ensa.web;

import ma.ensa.models.Utilisateur;
import ma.ensa.services.AuthService;
import javax.servlet.*;
import javax.servlet.http.*;
import java.io.IOException;

public class LoginServlet extends HttpServlet {

    private final AuthService auth = AuthService.getInstance();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse res)
            throws ServletException, IOException {
        HttpSession s = req.getSession(false);
        if (s != null && s.getAttribute("utilisateur") != null) {
            res.sendRedirect(req.getContextPath() + "/produit?action=list");
            return;
        }
        req.getRequestDispatcher("/WEB-INF/views/login.jsp").forward(req, res);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse res)
            throws ServletException, IOException {

        String login = req.getParameter("login");
        String mdp   = req.getParameter("motDePasse");

        if (login == null || login.trim().isEmpty()
                || mdp == null || mdp.trim().isEmpty()) {
            req.setAttribute("erreur", "Veuillez remplir tous les champs.");
            req.getRequestDispatcher("/WEB-INF/views/login.jsp").forward(req, res);
            return;
        }

        Utilisateur u = auth.authentifier(login.trim(), mdp);
        if (u != null) {
            HttpSession session = req.getSession(true);
            session.setAttribute("utilisateur", u);
            session.setMaxInactiveInterval(30 * 60);
            res.sendRedirect(req.getContextPath() + "/produit?action=list");
        } else {
            req.setAttribute("erreur", "Login ou mot de passe incorrect.");
            req.setAttribute("loginSaisi", login);
            req.getRequestDispatcher("/WEB-INF/views/login.jsp").forward(req, res);
        }
    }
}