package ma.ensa.web;

import ma.ensa.models.Produit;
import ma.ensa.services.ProduitService;
import ma.ensa.services.ProduitServiceImpl;

import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;
import java.util.List;

/**
 * Servlet centrale MVC2 — gère toutes les actions sur les produits.
 *
 * GET  /produit?action=list             → liste tous les produits
 * GET  /produit?action=list&id=X        → recherche par ID
 * GET  /produit?action=edit&id=X        → charge produit dans formulaire
 * GET  /produit?action=delete&id=X      → supprime et redirige
 * POST /produit?action=add              → ajoute un produit
 * POST /produit?action=update           → met à jour un produit
 */
@WebServlet("/produit")
public class ProduitServlet extends HttpServlet {

    private final ProduitService service = ProduitServiceImpl.getInstance();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse res)
            throws ServletException, IOException {

        String action = req.getParameter("action");
        if (action == null) action = "list";

        switch (action) {

            case "list":
                actionList(req, res);
                break;

            case "edit":
                actionEdit(req, res);
                break;

            case "delete":
                actionDelete(req, res);
                break;

            default:
                actionList(req, res);
        }
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse res)
            throws ServletException, IOException {

        String action = req.getParameter("action");
        if (action == null) action = "list";

        switch (action) {
            case "add":    actionAdd(req, res);    break;
            case "update": actionUpdate(req, res); break;
            default:       actionList(req, res);
        }
    }

    // ── LIST ──────────────────────────────────────────
    private void actionList(HttpServletRequest req, HttpServletResponse res)
            throws ServletException, IOException {

        String idParam = req.getParameter("id");
        List<Produit> liste;

        if (idParam != null && !idParam.trim().isEmpty()) {
            try {
                Produit p = service.getById(Long.parseLong(idParam.trim()));
                liste = new java.util.ArrayList<>();
                if (p != null) {
                    liste.add(p);
                } else {
                    req.setAttribute("infoMessage",
                            "Aucun produit trouvé avec l'ID : " + idParam);
                    liste = service.getAll();
                }
            } catch (NumberFormatException e) {
                req.setAttribute("erreurMessage", "L'ID doit être un nombre entier.");
                liste = service.getAll();
            }
        } else {
            liste = service.getAll();
        }

        req.setAttribute("listeProduits", liste);
        req.getRequestDispatcher("/WEB-INF/views/index.jsp").forward(req, res);
    }

    // ── EDIT ──────────────────────────────────────────
    private void actionEdit(HttpServletRequest req, HttpServletResponse res)
            throws ServletException, IOException {
        try {
            Long id   = Long.parseLong(req.getParameter("id"));
            Produit p = service.getById(id);

            if (p == null) {
                req.setAttribute("erreurMessage",
                        "Produit introuvable (ID : " + id + ").");
            } else {
                req.setAttribute("produitEdit", p);
            }
        } catch (NumberFormatException e) {
            req.setAttribute("erreurMessage", "ID invalide.");
        }

        req.setAttribute("listeProduits", service.getAll());
        req.getRequestDispatcher("/WEB-INF/views/index.jsp").forward(req, res);
    }

    // ── ADD ───────────────────────────────────────────
    private void actionAdd(HttpServletRequest req, HttpServletResponse res)
            throws ServletException, IOException {

        String nom         = req.getParameter("nom");
        String description = req.getParameter("description");
        String prixStr     = req.getParameter("prix");

        if (estVide(nom) || estVide(description) || estVide(prixStr)) {
            req.setAttribute("erreurMessage", "Tous les champs sont obligatoires.");
            req.setAttribute("listeProduits", service.getAll());
            req.getRequestDispatcher("/WEB-INF/views/index.jsp").forward(req, res);
            return;
        }

        try {
            double prix = Double.parseDouble(prixStr.trim());
            if (prix < 0) throw new NumberFormatException();
            service.add(new Produit(nom.trim(), description.trim(), prix));
            res.sendRedirect(req.getContextPath() + "/produit?action=list");
        } catch (NumberFormatException e) {
            req.setAttribute("erreurMessage", "Le prix doit être un nombre positif.");
            req.setAttribute("listeProduits", service.getAll());
            req.getRequestDispatcher("/WEB-INF/views/index.jsp").forward(req, res);
        }
    }

    // ── UPDATE ────────────────────────────────────────
    private void actionUpdate(HttpServletRequest req, HttpServletResponse res)
            throws ServletException, IOException {

        String idStr       = req.getParameter("idProduit");
        String nom         = req.getParameter("nom");
        String description = req.getParameter("description");
        String prixStr     = req.getParameter("prix");

        if (estVide(nom) || estVide(description) || estVide(prixStr)) {
            req.setAttribute("erreurMessage", "Tous les champs sont obligatoires.");
            req.setAttribute("listeProduits", service.getAll());
            req.getRequestDispatcher("/WEB-INF/views/index.jsp").forward(req, res);
            return;
        }

        try {
            Long id     = Long.parseLong(idStr);
            double prix = Double.parseDouble(prixStr.trim());
            if (prix < 0) throw new NumberFormatException();

            Produit p = new Produit();
            p.setIdProduit(id);
            p.setNom(nom.trim());
            p.setDescription(description.trim());
            p.setPrix(prix);

            service.update(p);
            res.sendRedirect(req.getContextPath() + "/produit?action=list");

        } catch (NumberFormatException e) {
            req.setAttribute("erreurMessage", "Données invalides.");
            req.setAttribute("listeProduits", service.getAll());
            req.getRequestDispatcher("/WEB-INF/views/index.jsp").forward(req, res);
        }
    }

    // ── DELETE ────────────────────────────────────────
    private void actionDelete(HttpServletRequest req, HttpServletResponse res)
            throws ServletException, IOException {
        try {
            Long id = Long.parseLong(req.getParameter("id"));
            service.delete(id);
            res.sendRedirect(req.getContextPath() + "/produit?action=list");
        } catch (NumberFormatException e) {
            req.setAttribute("erreurMessage", "ID invalide.");
            req.setAttribute("listeProduits", service.getAll());
            req.getRequestDispatcher("/WEB-INF/views/index.jsp").forward(req, res);
        }
    }

    private boolean estVide(String s) {
        return s == null || s.trim().isEmpty();
    }
}