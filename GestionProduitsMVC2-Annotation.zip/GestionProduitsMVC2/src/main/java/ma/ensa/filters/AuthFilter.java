package ma.ensa.filters;

import javax.servlet.*;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.*;
import java.io.IOException;

@WebFilter("/*")
public class AuthFilter implements Filter {

    @Override
    public void doFilter(ServletRequest req, ServletResponse res, FilterChain chain)
            throws IOException, ServletException {

        HttpServletRequest  request  = (HttpServletRequest)  req;
        HttpServletResponse response = (HttpServletResponse) res;

        String path = request.getRequestURI()
                             .substring(request.getContextPath().length());

        boolean estPublic = path.equals("/login")
                         || path.equals("/logout")
                         || path.startsWith("/css/");

        if (estPublic) { chain.doFilter(req, res); return; }

        HttpSession session   = request.getSession(false);
        boolean estConnecte   = session != null
                             && session.getAttribute("utilisateur") != null;

        if (estConnecte) {
            chain.doFilter(req, res);
        } else {
            response.sendRedirect(request.getContextPath() + "/login");
        }
    }

    @Override public void init(FilterConfig fc) {}
    @Override public void destroy() {}
}