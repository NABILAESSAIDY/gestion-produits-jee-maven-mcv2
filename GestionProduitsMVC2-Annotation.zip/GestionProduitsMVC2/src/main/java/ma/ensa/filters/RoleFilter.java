package ma.ensa.filters;

import ma.ensa.models.Utilisateur;
import javax.servlet.*;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.*;
import java.io.IOException;

@WebFilter({"/produit"})
public class RoleFilter implements Filter {

    @Override
    public void doFilter(ServletRequest req, ServletResponse res, FilterChain chain)
            throws IOException, ServletException {

        HttpServletRequest  request  = (HttpServletRequest)  req;
        HttpServletResponse response = (HttpServletResponse) res;

        String action = request.getParameter("action");

        // Actions réservées aux ADMIN
        boolean estActionAdmin = "add".equals(action)
                              || "delete".equals(action)
                              || "edit".equals(action)
                              || "update".equals(action);

        if (!estActionAdmin) { chain.doFilter(req, res); return; }

        HttpSession session = request.getSession(false);
        Utilisateur u = (session != null)
                      ? (Utilisateur) session.getAttribute("utilisateur")
                      : null;

        if (u != null && u.isAdmin()) {
            chain.doFilter(req, res);
        } else {
            request.setAttribute("erreurCode",    403);
            request.setAttribute("erreurMessage", "Accès refusé : action réservée aux administrateurs.");
            request.getRequestDispatcher("/WEB-INF/views/erreur.jsp").forward(request, response);
        }
    }

    @Override public void init(FilterConfig fc) {}
    @Override public void destroy() {}
}