package ma.ensa.models;

public class Utilisateur {

    public enum Role { ADMIN, USER }

    private String login;
    private String motDePasse;
    private Role role;

    public Utilisateur(String login, String motDePasse, Role role) {
        this.login = login;
        this.motDePasse = motDePasse;
        this.role = role;
    }

    public String getLogin()        { return login; }
    public String getMotDePasse()   { return motDePasse; }
    public Role getRole()           { return role; }
    public boolean isAdmin()        { return Role.ADMIN.equals(role); }
}