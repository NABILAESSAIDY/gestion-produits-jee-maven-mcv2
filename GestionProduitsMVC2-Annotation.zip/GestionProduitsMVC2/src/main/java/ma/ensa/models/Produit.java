package ma.ensa.models;

import javax.persistence.*;

/**
 * Entité JPA/Hibernate mappée sur la table "produits".
 * Les annotations remplacent le fichier hbm.xml.
 */
@Entity
@Table(name = "produits")
public class Produit {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_produit")
    private Long idProduit;

    @Column(name = "nom", nullable = false, length = 150)
    private String nom;

    @Column(name = "description", length = 500)
    private String description;

    @Column(name = "prix", nullable = false)
    private Double prix;

    public Produit() {}

    public Produit(String nom, String description, Double prix) {
        this.nom = nom;
        this.description = description;
        this.prix = prix;
    }

    // Getters / Setters
    public Long getIdProduit()              { return idProduit; }
    public void setIdProduit(Long id)       { this.idProduit = id; }
    public String getNom()                  { return nom; }
    public void setNom(String nom)          { this.nom = nom; }
    public String getDescription()          { return description; }
    public void setDescription(String d)    { this.description = d; }
    public Double getPrix()                 { return prix; }
    public void setPrix(Double prix)        { this.prix = prix; }
}