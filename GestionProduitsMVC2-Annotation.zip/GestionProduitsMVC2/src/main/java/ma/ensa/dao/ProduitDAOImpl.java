package ma.ensa.dao;

import ma.ensa.models.Produit;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import java.util.List;

/**
 * Implémentation du DAO avec Hibernate.
 * Chaque méthode ouvre une session, exécute l'opération
 * dans une transaction, puis ferme la session.
 */
public class ProduitDAOImpl implements ProduitDAO {

    private SessionFactory sf = HibernateUtil.getSessionFactory();

    @Override
    public void add(Produit p) {
        Transaction tx = null;
        try (Session s = sf.openSession()) {
            tx = s.beginTransaction();
            s.save(p);
            tx.commit();
        } catch (Exception e) {
            if (tx != null) tx.rollback();
            throw new RuntimeException("Erreur ajout produit", e);
        }
    }

    @Override
    public void delete(Long id) {
        Transaction tx = null;
        try (Session s = sf.openSession()) {
            tx = s.beginTransaction();
            Produit p = s.get(Produit.class, id);
            if (p != null) s.delete(p);
            tx.commit();
        } catch (Exception e) {
            if (tx != null) tx.rollback();
            throw new RuntimeException("Erreur suppression produit", e);
        }
    }

    @Override
    public void update(Produit p) {
        Transaction tx = null;
        try (Session s = sf.openSession()) {
            tx = s.beginTransaction();
            s.update(p);
            tx.commit();
        } catch (Exception e) {
            if (tx != null) tx.rollback();
            throw new RuntimeException("Erreur mise à jour produit", e);
        }
    }

    @Override
    public Produit getById(Long id) {
        try (Session s = sf.openSession()) {
            return s.get(Produit.class, id);
        }
    }

    @Override
    @SuppressWarnings("unchecked")
    public List<Produit> getAll() {
        try (Session s = sf.openSession()) {
            return s.createQuery("FROM Produit ORDER BY idProduit").list();
        }
    }
}